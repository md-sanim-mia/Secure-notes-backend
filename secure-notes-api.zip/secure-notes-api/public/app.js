(() => {
  const API = "/api/v1";
  const $ = (id) => document.getElementById(id);
  let token = sessionStorage.getItem("token");
  let me = null;

  const h = (tag, props = {}, ...kids) => {
    const el = document.createElement(tag);
    Object.assign(el, props);
    kids.flat().forEach((k) => el.append(k));
    return el;
  };
  const say = (text = "") => ($("msg").textContent = text);
  const csv = (s) => s.split(",").map((x) => x.trim()).filter(Boolean);

  async function api(method, path, body) {
    const res = await fetch(API + path, {
      method,
      headers: {
        "Content-Type": "application/json",
        ...(token && { Authorization: "Bearer " + token }),
      },
      body: body && JSON.stringify(body),
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (res.status === 401 && token) logout();
      const details = (json.errorSources || []).map((e) => `${e.path}: ${e.message}`).join("; ");
      throw new Error((json.message || "Request failed") + (details ? ` (${details})` : ""));
    }
    return json;
  }
  const guard = (fn) => async (...a) => {
    try { say(); await fn(...a); } catch (e) { say(e.message); }
  };

  // ---------- generic cursor-paginated list ----------
  function pager({ listEl, moreEl, url, render }) {
    let cursor = null;
    const load = guard(async (reset) => {
      if (reset) { cursor = null; listEl.replaceChildren(); }
      const sep = url().includes("?") ? "&" : "?";
      const r = await api("GET", url() + sep + "limit=5" + (cursor ? "&cursor=" + encodeURIComponent(cursor) : ""));
      render(r, listEl);
      cursor = r.meta.nextCursor;
      moreEl.classList.toggle("hidden", !r.meta.hasMore);
    });
    moreEl.onclick = () => load(false);
    return { reset: () => load(true) };
  }

  // ---------- notes ----------
  const notes = pager({
    listEl: $("notesList"), moreEl: $("notesMore"),
    url: () => "/notes" + ($("noteOwner").value.trim() ? "?owner=" + $("noteOwner").value.trim() : ""),
    render: (r, el) => r.data.forEach((n) => {
      const owner = n.owner && n.owner.name ? ` · by ${n.owner.name}` : "";
      const mine = !n.owner || typeof n.owner === "string" || n.owner._id === me._id;
      el.append(h("div", { className: "card" },
        h("b", { textContent: n.title }),
        h("span", { className: "muted", textContent: ` ${new Date(n.createdAt).toLocaleString()}${owner}` }),
        h("p", { textContent: n.content }),
        mine ? h("div", {},
          h("button", { textContent: "Edit", onclick: guard(async () => {
            const title = prompt("Title", n.title); if (title === null) return;
            const content = prompt("Content", n.content); if (content === null) return;
            await api("PATCH", "/notes/" + n._id, { title, content }); notes.reset();
          }) }),
          h("button", { textContent: "Delete", onclick: guard(async () => {
            if (confirm("Delete this note?")) { await api("DELETE", "/notes/" + n._id); notes.reset(); }
          }) })) : ""));
    }),
  });
  $("noteForm").onsubmit = guard(async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    await api("POST", "/notes", { title: f.get("title"), content: f.get("content") });
    e.target.reset(); notes.reset();
  });
  $("noteOwnerApply").onclick = () => notes.reset();

  // ---------- posts ----------
  let postMode = "all";
  const posts = pager({
    listEl: $("postsList"), moreEl: $("postsMore"),
    url: () => (postMode === "all" ? "/posts" : "/posts/user/" + $("postUser").value.trim()),
    render: (r, el) => {
      const list = Array.isArray(r.data) ? r.data : r.data.posts;
      if (!Array.isArray(r.data) && !el.children.length)
        el.append(h("p", { className: "muted", textContent: `Posts by ${r.data.name} (${r.data._id})` }));
      list.forEach((p) => el.append(h("div", { className: "card" },
        h("b", { textContent: p.title }),
        h("span", { className: "muted", textContent: ` author: ${p.author} · ${new Date(p.createdAt).toLocaleString()}` }),
        h("p", { textContent: p.content }),
        p.author === me._id ? h("button", { textContent: "Delete", onclick: guard(async () => {
          await api("DELETE", "/posts/" + p._id); posts.reset();
        }) }) : "")));
    },
  });
  $("postForm").onsubmit = guard(async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    await api("POST", "/posts", { title: f.get("title"), content: f.get("content") });
    e.target.reset(); postMode = "all"; posts.reset();
  });
  $("postUserApply").onclick = () => { postMode = "user"; posts.reset(); };
  $("postAll").onclick = () => { postMode = "all"; posts.reset(); };

  // ---------- admin: users ----------
  const users = pager({
    listEl: $("usersList"), moreEl: $("usersMore"), url: () => "/users",
    render: (r, el) => r.data.forEach((u) => el.append(h("div", { className: "card" },
      h("b", { textContent: u.name }),
      h("span", { className: "muted", textContent: ` ${u.email} · ${u.role} · [${(u.interests || []).join(", ")}] · id ${u._id}` }),
      h("div", {},
        h("button", { textContent: "Edit", onclick: guard(async () => {
          const name = prompt("Name", u.name); if (name === null) return;
          const role = prompt("Role (user/admin)", u.role); if (role === null) return;
          await api("PATCH", "/users/" + u._id, { name, role }); users.reset();
        }) }),
        h("button", { textContent: "Delete", onclick: guard(async () => {
          if (confirm("Delete this user and all their notes/posts?")) { await api("DELETE", "/users/" + u._id); users.reset(); }
        }) }))))),
  });
  $("userForm").onsubmit = guard(async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    await api("POST", "/users", {
      name: f.get("name"), email: f.get("email"), password: f.get("password"),
      role: f.get("role"), interests: csv(f.get("interests")),
    });
    e.target.reset(); users.reset();
  });

  // ---------- admin: interests ----------
  const interests = pager({
    listEl: $("interestsList"), moreEl: $("interestsMore"),
    url: () => "/users/interests" + ($("interestFilter").value.trim() ? "?interest=" + encodeURIComponent($("interestFilter").value.trim()) : ""),
    render: (r, el) => r.data.forEach((g) => el.append(h("div", { className: "card" },
      h("b", { textContent: `${g.interest} (${g.count})` }),
      h("div", { className: "muted", textContent: g.users.map((u) => u.name).join(", ") })))),
  });
  $("interestApply").onclick = () => interests.reset();

  // ---------- auth + tabs ----------
  const loaders = { notes, posts, users, interests };
  function showTab(name) {
    ["notes", "posts", "users", "interests"].forEach((t) => $("tab-" + t).classList.toggle("hidden", t !== name));
    document.querySelectorAll("#tabs button").forEach((b) => b.classList.toggle("active", b.dataset.tab === name));
    loaders[name].reset();
  }
  document.querySelectorAll("#tabs button").forEach((b) => (b.onclick = () => showTab(b.dataset.tab)));

  async function enter() {
    const r = await api("GET", "/users/me");
    me = r.data;
    $("who").textContent = `${me.name} (${me.role})`;
    document.querySelectorAll(".admin-only").forEach((el) => el.classList.toggle("hidden", me.role !== "admin"));
    $("auth").classList.add("hidden");
    $("app").classList.remove("hidden");
    showTab("notes");
  }
  function logout() {
    token = null; me = null; sessionStorage.removeItem("token");
    $("app").classList.add("hidden"); $("auth").classList.remove("hidden");
  }
  $("logout").onclick = logout;

  const authSubmit = (path, extra) => guard(async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target));
    if (extra) extra(f);
    const r = await api("POST", path, f);
    token = r.data.accessToken; sessionStorage.setItem("token", token);
    e.target.reset(); await enter();
  });
  $("loginForm").onsubmit = authSubmit("/auth/login");
  $("registerForm").onsubmit = authSubmit("/auth/register", (f) => (f.interests = csv(f.interests || "")));

  if (token) enter().catch(logout);
})();
